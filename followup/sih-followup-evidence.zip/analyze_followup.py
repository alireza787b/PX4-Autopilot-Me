"""Analyze the PX4 #29954 SITL runs at native ULog publication times."""
import csv
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from pyulog import ULog

ROOT = Path(__file__).parent
TOPICS = [
    "vtol_vehicle_status", "vehicle_attitude", "vehicle_attitude_setpoint",
    "fw_virtual_attitude_setpoint", "vehicle_angular_velocity", "vehicle_local_position",
    "vehicle_control_mode", "tecs_status", "actuator_motors", "airspeed_validated",
    "manual_control_setpoint",
]


def quaternion(topic, prefix):
    return np.column_stack([topic[f"{prefix}[{axis}]"] for axis in range(4)]).astype(float)


def to_fixed_wing(q):
    w, x, y, z = q.T
    return np.column_stack((w-y, x-z, w+y, z+x)) / np.sqrt(2)


def pitch(q, rotate=False):
    w, x, y, z = (to_fixed_wing(q) if rotate else q).T
    return np.rad2deg(np.arcsin(np.clip(2 * (w*y - z*x), -1, 1)))


def stamps(topic):
    return topic["timestamp"].astype(np.int64)


def first_where(t, threshold):
    idx = np.flatnonzero(t >= threshold)
    return int(idx[0]) if len(idx) else None


def quat_distance(a, b):
    return np.minimum(np.linalg.norm(a-b, axis=1), np.linalg.norm(a+b, axis=1))


def audit(directory):
    name = directory.name
    variant, fixture, trial = name.split("-", 2)
    event_file = directory / "output/events.jsonl"
    events = [json.loads(line) for line in event_file.read_text().splitlines()] if event_file.is_file() else []
    result = {"run": name, "variant": variant, "fixture": fixture, "trial": trial,
              "harness_completed": any(e["event"] == "completed" for e in events)}
    paths = sorted(directory.glob("output/fs/log/*/*.ulg"))
    if not paths:
        return result, {}
    (path,) = paths
    log = ULog(str(path), TOPICS)
    topics = {x.name: x.data for x in log.data_list if x.multi_id == 0}
    result.update(log_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                  binary_sha256=(directory/"binary.sha256").read_text().strip(),
                  log_firmware=log.msg_info_dict["ver_sw"], log_hardware=log.msg_info_dict["ver_hw"],
                  ulog_dropouts=len(log.dropouts),
                  airframe=log.initial_parameters["SYS_AUTOSTART"],
                  use_airspeed=log.initial_parameters["FW_USE_AIRSPD"])
    status = topics["vtol_vehicle_status"]
    state = status["vehicle_vtol_state"]
    result["vtol_states"] = "|".join(map(str, state[np.r_[True, state[1:] != state[:-1]]]))
    fw = np.flatnonzero(state == 4)
    front = np.flatnonzero(state == 1)
    if not (len(fw) and len(front)):
        return result, {}
    entry = int(stamps(status)[fw[0]])
    t = {k: (stamps(v)-entry)/1e6 for k, v in topics.items()}
    q_actual = quaternion(topics["vehicle_attitude"], "q")
    rotate = fixture in ("xvert", "angle")
    p_actual = pitch(q_actual, rotate=rotate)
    entry_angle = np.interp(0, t["vehicle_attitude"], p_actual)
    result["front_duration_s"] = (entry-int(stamps(status)[front[0]]))/1e6
    result["entry_pitch_deg"] = entry_angle

    sp = topics["vehicle_attitude_setpoint"]
    virtual = topics["fw_virtual_attitude_setpoint"]
    sp_q, in_q = quaternion(sp, "q_d"), quaternion(virtual, "q_d")
    sp_t, in_t = t["vehicle_attitude_setpoint"], t["fw_virtual_attitude_setpoint"]
    matched, routed_i, virtual_i = np.intersect1d(sp_t, in_t, return_indices=True)
    after_match = matched >= -.008  # producer timestamp can slightly precede mode status
    if rotate:
        # Reject coincident transition samples expressed in the hover frame.
        direct = quat_distance(sp_q[routed_i], in_q[virtual_i])
        converted = quat_distance(to_fixed_wing(sp_q[routed_i]), in_q[virtual_i])
        after_match &= (matched >= 0) | (direct < converted)
    routed_i, virtual_i, matched = routed_i[after_match], virtual_i[after_match], matched[after_match]
    if len(matched) == 0:
        raise RuntimeError(f"No source-matched FW sample in {name}")
    route_diff = quat_distance(sp_q[routed_i], in_q[virtual_i])
    result["first_matched_fw_ms"] = 1000*matched[0]
    result["first_fw_input_pitch_deg"] = float(pitch(in_q[virtual_i[:1]])[0])
    result["first_fw_routed_pitch_deg"] = float(pitch(sp_q[routed_i[:1]])[0])
    result["first_fw_quat_delta"] = float(route_diff[0])
    result["last_fw_input_ms"] = 1000*matched[-1]
    opening = (matched >= .016) & (matched < 1.2)
    if np.any(opening):
        result["max_quat_delta_16ms_to_1p2s"] = float(np.max(route_diff[opening]))
    settled = (matched >= 1.2) & (matched < 2.)
    if np.any(settled):
        result["max_quat_delta_1p2_to_2s"] = float(np.max(route_diff[settled]))
    delta_pitch = np.abs(np.diff(pitch(sp_q[routed_i])))
    expiry = (matched[1:] >= .080) & (matched[1:] <= .180)
    if np.any(expiry):
        result["max_pitch_step_80_to_180_ms_deg"] = float(np.max(delta_pitch[expiry]))
    bracket_pre = np.flatnonzero(sp_t < -.025)[-1]
    bracket_post = first_where(sp_t, .050)
    result["bracket_pitch_pre_deg"] = float(pitch(sp_q[bracket_pre:bracket_pre+1], rotate=rotate)[0])
    result["bracket_pitch_post_deg"] = float(pitch(sp_q[bracket_post:bracket_post+1])[0])
    if sp_t[bracket_post] <= .075:
        result["bracket_pitch_change_deg"] = abs(result["bracket_pitch_post_deg"]-result["bracket_pitch_pre_deg"])

    rate_t, body_rate = t["vehicle_angular_velocity"], np.rad2deg(topics["vehicle_angular_velocity"]["xyz[1]"])
    window = np.flatnonzero((rate_t >= 0) & (rate_t < 1.5))
    peak = window[np.argmin(body_rate[window])]
    result["peak_nose_down_deg_s"] = -float(body_rate[peak])
    result["peak_offset_ms"] = 1000*rate_t[peak]
    pos = topics["vehicle_local_position"]
    pos_t = t["vehicle_local_position"]
    height = np.interp(0, pos_t, pos["z"])-pos["z"]
    result["loss_entry_plus3_m"] = max(0., -float(np.min(height[(pos_t >= 0) & (pos_t <= 3)])))
    front_height = np.interp(-result["front_duration_s"], pos_t, pos["z"])-pos["z"]
    result["loss_front_to_plus3_m"] = max(0., -float(np.min(front_height[(pos_t >= -result["front_duration_s"]) & (pos_t <= 3)])))

    tecs_t = t.get("tecs_status", np.array([]))
    tecs_start = first_where(tecs_t, 0)
    if tecs_start is not None:
        tecs_first = tecs_t[tecs_start]
        result["first_tecs_ms"] = 1000*tecs_first
        pre_tecs = (matched >= 0) & (matched < tecs_first)
        result["fw_pairs_before_tecs"] = int(np.count_nonzero(pre_tecs))
        if np.any(pre_tecs):
            result["max_pitch_override_before_tecs_deg"] = float(np.max(np.abs(
                pitch(sp_q[routed_i[pre_tecs]]) - pitch(in_q[virtual_i[pre_tecs]])
            )))
    else:
        result["fw_pairs_without_tecs_after_entry"] = int(np.count_nonzero(matched >= 0))
        result["height_change_at_last_fw_input_m"] = float(np.interp(matched[-1], pos_t, height))
    ctrl = topics["vehicle_control_mode"]
    if trial == "modehop":
        ct = t["vehicle_control_mode"]
        altitude = ctrl["flag_control_altitude_enabled"].astype(bool)
        off = ct[(ct >= 0) & ~altitude]
        if len(off):
            restored = ct[(ct > off[0]) & altitude]
            result["altitude_control_off_ms"] = 1000*float(off[0])
            if len(restored):
                result["altitude_control_restored_ms"] = 1000*float(restored[0])
                early = (matched >= restored[0] + .020) & (matched <= restored[0] + .240)
                if np.any(early):
                    result["max_quat_delta_after_altitude_restore"] = float(np.max(route_diff[early]))
                    result["max_pitch_delta_after_altitude_restore_deg"] = float(np.max(np.abs(
                        pitch(sp_q[routed_i[early]]) - pitch(in_q[virtual_i[early]])
                    )))
    if trial == "manual":
        manual = topics["manual_control_setpoint"]
        mt = t["manual_control_setpoint"]
        early = (matched >= .12) & (matched < 1.35)
        pilot = (mt >= 0) & (mt < 1.5) & manual["valid"].astype(bool)
        ctrl_t = t["vehicle_control_mode"]
        entry_index = np.searchsorted(ctrl_t, 0, side="right")-1
        result["alt_control_at_entry"] = bool(ctrl["flag_control_altitude_enabled"][entry_index])
        result["pilot_pitch_low"] = float(np.min(manual["pitch"][pilot]))
        result["pilot_pitch_high"] = float(np.max(manual["pitch"][pilot]))
        result["manual_min_pitch_request_deg"] = float(np.min(pitch(sp_q[routed_i[early]])))
        result["manual_max_pitch_request_deg"] = float(np.max(pitch(sp_q[routed_i[early]])))
        result["manual_max_quat_delta"] = float(np.max(route_diff[early]))

    pl = {
        "routed": (sp_t, np.where(sp_t < 0, pitch(sp_q, rotate), pitch(sp_q))),
        "incoming": (matched, pitch(in_q[virtual_i])),
        "actual": (t["vehicle_attitude"], p_actual),
        "rate": (rate_t, body_rate),
        "height": (pos_t, height),
    }
    return result, pl


def plot_case(all_plots, figure, selected, limits):
    fig, axes = plt.subplots(4, 1, sharex=True, figsize=(10, 9))
    colors = plt.rcParams["axes.prop_cycle"].by_key()["color"]
    for index, name in enumerate(selected):
        color = colors[index]
        series = all_plots[name]
        label = name.replace("_diag", "").replace("-", " ")
        t, p = series["routed"]
        for side, show in enumerate([t < -.025, t > .025]):
            points = show & (t >= limits[0]) & (t <= limits[1])
            axes[0].plot(t[points], p[points], color=color, label=label if side == 0 else "")
        tt, pp = series["incoming"]
        points = (tt >= .025) & (tt <= limits[1])
        axes[0].plot(tt[points], pp[points], ":", color=color, alpha=.7)
        for ax, key in zip(axes[1:], ("actual", "rate", "height")):
            tt, pp = series[key]
            points = (tt >= limits[0]) & (tt <= limits[1])
            ax.plot(tt[points], pp[points], color=color)
    axes[0].legend(loc="best", fontsize=9)
    for ax, ylabel in zip(axes, ("Pitch request (°)", "Measured pitch (°)", "Nose-up rate (°/s)", "Height change (m)")):
        ax.set_ylabel(ylabel)
        ax.axvline(0, color=".4", linewidth=1, linestyle="--")
        ax.grid(alpha=.25)
    axes[0].set_title(figure)
    axes[0].text(.01, .02, "Dotted lines are incoming FW pitch requests", transform=axes[0].transAxes, fontsize=9)
    axes[-1].set_xlabel("Seconds from fixed-wing entry")
    axes[-1].set_xlim(limits)
    fig.tight_layout()
    fig.savefig(ROOT / "evidence" / (figure.lower().replace(" ", "-")+".png"), dpi=160)
    plt.close(fig)


def main():
    results, plots = [], {}
    evidence = ROOT / "evidence"
    evidence.mkdir(exist_ok=True)
    for directory in sorted((ROOT / "runs").iterdir()):
        result, series = audit(directory)
        results.append(result)
        if series:
            plots[directory.name] = series
    col_names = list(dict.fromkeys(key for result in results for key in result))
    with (evidence/"metrics.csv").open("w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=col_names)
        writer.writeheader()
        writer.writerows(results)
    (evidence/"metrics.json").write_text(json.dumps(results, indent=2)+"\n")
    comparisons = [
        ("Nominal tailsitter handoff", ["stock-xvert-nominal", "guarded-xvert-nominal", "shared-xvert-nominal"], (-.45, 2.5)),
        ("Final patch nominal handoff", ["stock-xvert-nominal-r3", "shared_review-xvert-nominal"], (-.45, 2.5)),
        ("Delayed TECS status", ["stock_diag-xvert-tecs_gap", "guarded_diag-xvert-tecs_gap", "shared_diag-xvert-tecs_gap"], (-.4, 2.1)),
        ("Same build timeout comparison", ["compare_diag-xvert-tecs_gap", "compare_diag-xvert-tecs_gap_timeout"], (-.4, 2.1)),
        ("Prolonged status loss near 29 degrees", ["compare_diag-angle-tecs_absent_angle",
                                                  "compare_diag-angle-tecs_absent_angle_timeout"], (-.3, 8.)),
        ("Pitch gate comparison", ["stock_diag-angle-stock_gate", "stock_diag-angle-later_gate",
                                    "shared_diag-angle-stock_gate", "shared_diag-angle-later_gate"], (-.6, 2.5)),
    ]
    for title, names, bounds in comparisons:
        if all(name in plots for name in names):
            plot_case(plots, title, names, bounds)


if __name__ == "__main__":
    main()
