#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
variant=$1
fixture=$2
scenario=$3
label=$variant-$fixture-$scenario
if [[ $# -ge 4 ]]; then label="$label-$4"; fi
artifact=$(realpath "$root/builds/$variant")
run="$root/runs/$label"
name="px4-review29954-$label"
image=ghcr.io/px4/px4-dev-ros2-gazebo@sha256:4e7bb18e46f8007d3e601e25597f84117ef14d282df10999e2dc0a9fe7d4e1f2
sim_args=()
case "$fixture" in
    xvert|angle) autostart=10042; model=sihsim_xvert; simulator=sihsim ;;
    standard) autostart=10043; model=sihsim_standard_vtol; simulator=sihsim ;;
    tiltrotor)
        autostart=4020
        model=gz_tiltrotor
        simulator=gz
        sim_args=(-v "$root/../PB-Pitch-Handoff-PR/Tools/simulation/gz:/sim:ro"
            -e PX4_GZ_WORLD=default -e PX4_GZ_MODELS=/sim/models -e PX4_GZ_WORLDS=/sim/worlds
            -e GZ_SIM_RESOURCE_PATH=/sim/models -e GZ_IP=127.0.0.1 -e GZ_PARTITION="$name"
            -e GZ_SIM_SERVER_CONFIG_PATH=/sim/server.config -e HEADLESS=1)
        ;;
    *) exit 2 ;;
esac
rc_mode=4
tecs_delay=0
later_angle=0
airspeed=1
case "$scenario" in
    nominal) mission=generic ;;
    delayed) mission=stale_longer ;;
    tecs_gap|tecs_gap_timeout) mission=generic; tecs_delay=550000 ;;
    tecs_gap_angle|tecs_gap_angle_timeout) mission=generic; tecs_delay=550000; airspeed=0 ;;
    tecs_absent|tecs_absent_timeout) mission=generic; tecs_delay=9000000 ;;
    tecs_absent_angle|tecs_absent_angle_timeout) mission=generic; tecs_delay=9000000; airspeed=0 ;;
    stock_gate) mission=generic; airspeed=0 ;;
    later_gate) mission=generic; airspeed=0; later_angle=1 ;;
    manual) mission=stabilized; rc_mode=1 ;;
    modehop) mission=modehop; rc_mode=1 ;;
    abort) mission=abort ;;
    *) exit 2 ;;
esac
[[ -x "$artifact/bin/px4" ]]
mkdir -p "$root/runs"
mkdir "$run"
mkdir -p "$run/output/fs/etc/logging"
cp "$root/logger_topics.txt" "$run/output/fs/etc/logging/"
sha256sum "$artifact/bin/px4" | awk '{print $1}' > "$run/binary.sha256"
docker run -d --rm --name "$name" --network none --user "$(id -u):$(id -g)" \
    -v "$artifact:/clean:ro" -v "$run/output:/output" -v "$root/flight_driver.py:/regression.py:ro" \
    -e HOME=/output -e PX4_SYS_AUTOSTART="$autostart" -e PX4_SIM_MODEL="$model" \
    -e PX4_SIMULATOR="$simulator" -e PX4_SIM_SPEED_FACTOR=1 -e PX4_PARAM_COM_RC_IN_MODE="$rc_mode" \
    -e PX4_PARAM_SDLOG_PROFILE=0 -e PX4_PARAM_SDLOG_MODE=0 -e PX4_PARAM_FW_USE_AIRSPD="$airspeed" \
    -e PX4_PR29954_TECS_DELAY_US="$tecs_delay" -e PX4_PR29954_LATER_ANGLE="$later_angle" \
    -e PX4_PR29954_SCENARIO="$scenario" \
    "${sim_args[@]}" --entrypoint bash "$image" -c 'cd /output && exec /clean/bin/px4 -d -i 0 -w /output /clean/etc' \
    > "$run/container-id.txt"
cleanup() {
    docker logs "$name" > "$run/px4.log" 2>&1 || true
    docker stop -t 4 "$name" >/dev/null 2>&1 || true
}
trap cleanup EXIT

docker exec -e MAVLINK20=1 -e SIH_SIMULATION_ONLY=1 -e PB_SIM_MISSION="$mission" \
    -e SIH_FW_RESTART_DELAY_MS=550 "$name" python3 /regression.py > "$run/mission.log" 2>&1
docker exec "$name" bash -c 'cd /output && /clean/bin/px4-logger stop' > "$run/logger-close.log" 2>&1
rg -q '"event": "completed"' "$run/output/events.jsonl"
